#!/bin/bash
javac -sourcepath ../init ../init/*.java;
cd ../init;
java Initializer;