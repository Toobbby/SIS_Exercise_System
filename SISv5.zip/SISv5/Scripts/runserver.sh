#!/bin/bash
cd ../NewSISServer/;
javac *.java;
java SISServer;