static String alert_msg = "Patient has abnormal bloodPressure because of uncomfortable temperature";
static String doctorEmail = "sisfortest@outlook.com"; // default email
static ArrayList<Double> tempRecord = new ArrayList<Double>();