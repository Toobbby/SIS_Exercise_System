String date = kvList.getValue("Date");
String temp = kvList.getValue("Temp");

System.out.println("The temp is " + temp);
System.out.println("The date is " + date);